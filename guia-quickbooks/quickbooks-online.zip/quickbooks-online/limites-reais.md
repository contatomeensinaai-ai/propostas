# O que funciona / o que NAO funciona (comprovado em teste real)

Esta pagina e HONESTA. Cada item foi rodado contra um sandbox real da Intuit
(Accounting API v3, `minorversion=73`). Nao e suposicao nem memoria de doc.

## O que FUNCIONA (provado)

| Capacidade | Como | Status |
|---|---|---|
| OAuth2 refresh token | POST em `oauth2/v1/tokens/bearer` com `grant_type=refresh_token` | OK — access token renovado |
| Ler empresa / dados | `SELECT * FROM CompanyInfo / Customer / Account` | OK |
| Descobrir Projects | `Customer` com `IsProject=true` (Project = sub-customer especial) | OK — filtro no JSON retornado |
| Criar despesa (Purchase) | POST `Purchase` com `AccountBasedExpenseLineDetail` | OK — HTTP 200, `Id` retornado |
| Vincular despesa a Project | `AccountBasedExpenseLineDetail.CustomerRef` = Id do Project | **OK — CustomerRef persistiu no read-back** |
| Marcar como faturavel | `BillableStatus: "Billable"` | OK — gera ReimburseCharge |
| Read-back de verificacao | GET `Purchase/{id}` e conferir a linha | OK — CustomerRef volta gravado |
| Relatorios contabeis | GET `reports/ProfitAndLoss`, `BalanceSheet`, etc. | OK |

**Resultado do teste de vinculo despesa->projeto: SIM.** O `CustomerRef` foi
gravado na linha, `BillableStatus=Billable`, e a Intuit criou o `ReimburseCharge`.

## O que NAO funciona (limite real — nao insista)

| Tentativa | Realidade comprovada |
|---|---|
| Criar Project via API (`IsProject=true`) | **NAO suportado.** O Project precisa existir na TELA do QBO. Via API voce so cria sub-customer comum (`Job=true`), que serve de proxy mas nao e um Project real. |
| Usar Projects sem plano Plus/Advanced | **Projects exige QBO Plus ou Advanced.** No QBO Simple Start/Essentials o recurso nao existe. |
| Ler extrato bancario / transacoes cruas do banco | **A API NAO le extrato bancario.** Ela expoe entidades contabeis (Purchase, Bill, Invoice) e relatorios — nao o feed bruto do banco. |
| Filtrar `WHERE IsProject = true` na query | Nao e confiavel em toda minor version. Solucao: puxar `Customer` e filtrar `IsProject` no JSON (e o que os scripts fazem). |

## Como confirmar de verdade (dupla prova)
Nao diga "funcionou" so pela resposta da API. Confira nas DUAS frentes:
1. **Saida do script** — VEREDITO diz "SIM" e o `CustomerRef.value` == Id do Project.
2. **Tela do QBO** — abra o Project > aba de custos/transacoes e veja a despesa listada.

## Observacao sobre a documentacao da Intuit
As paginas de doc da Intuit sao SPAs em JavaScript e nem sempre raspam bem em
texto. Por isso a **fonte de verdade e a saida do script** rodando contra a API,
nao a memoria do modelo. Se um campo divergir, o proprio POST retorna o erro
exato da Intuit (copie a mensagem — ela diz o campo/motivo).
