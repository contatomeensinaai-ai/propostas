# Checklist — deu certo / nao deu certo

Duas frentes de prova: a **resposta da API** (o script imprime) e a **tela do
QBO** (confirmacao visual). So diga "resolvido" com as duas.

## Conexao (`test-connection.js`)
- [ ] Imprime "access token obtido" (OAuth ok).
- [ ] Imprime o nome da empresa em CompanyInfo (realm correto).
- [ ] Lista Customers e Accounts sem erro.
- [ ] Termina com "CONEXAO OK".

## Despesa por projeto (`create-project-expense.js`)
### DEU CERTO se:
- [ ] PASSO 5 imprime "Purchase criada. Id=..." (POST aceito, HTTP 200).
- [ ] VEREDITO imprime "SIM - o CustomerRef ficou gravado na linha".
- [ ] `CustomerRef.value` retornado == `Id` do Project usado.
- [ ] "Alvo usado" no RESUMO idealmente e `IsProject` (Project real), nao apenas
      `SubCustomer(Job) PROXY`.
- [ ] Na tela do QBO: menu Projects > abra o Project > aba de custos: a despesa
      aparece atribuida ao Project.

### NAO DEU CERTO / limite confirmado se:
- [ ] "Alvo usado" e `SubCustomer(Job) PROXY` => voce nao tinha Project real;
      crie um na tela do QBO (menu Projects) e rode de novo.
- [ ] VEREDITO diz "NAO - o CustomerRef NAO voltou". Anote a `minorversion`.
- [ ] POST retorna HTTP 400 citando `CustomerRef`/`BillableStatus`. Copie a
      mensagem exata da Intuit — ela diz o campo/motivo.

## Relatorios (`pull-reports.js`)
- [ ] Imprime o nome do relatorio, periodo e moeda.
- [ ] Imprime as linhas do P&L (ou do relatorio pedido).
- [ ] Salva o JSON cru em `scripts/out/`.

## Como reportar
Cole SÓ a linha VEREDITO e a linha RESUMO FINAL + se olhou a tela (aparece no
Project? sim/nao) + a `minorversion` usada (padrao 73).

> SEGURANÇA: NUNCA cole linhas que contenham token, refresh_token, client
> secret ou qualquer credencial. Só as linhas VEREDITO e RESUMO FINAL — essas
> não têm segredo.
