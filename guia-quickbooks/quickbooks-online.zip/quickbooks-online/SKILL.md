---
name: quickbooks-online
description: Use quando o usuario quiser conectar o QuickBooks Online (QBO), organizar/lancar despesas por obra ou projeto, testar a conexao ou renovar token do QuickBooks, puxar relatorio financeiro (P&L / DRE, balanco) ou entender o que a integracao do QuickBooks permite. Publico leigo, sem terminal: o Claude conduz e roda os scripts pelo usuario.
---

# QuickBooks Online — o Claude conecta, lanca despesas por projeto e puxa relatorios PELO usuario

## Papel do Claude nesta skill
O usuario e LEIGO e NAO usa terminal. VOCE (Claude) conduz a conversa em
linguagem simples e EXECUTA os scripts por ele usando a ferramenta de rodar
comandos (Bash). O usuario so conversa: passa credenciais e dados da nota. VOCE
roda `node ...`, le a saida e EXPLICA o resultado em portugues simples.

**Regras de conducao (inegociaveis):**
- NUNCA peca pro usuario digitar comando no terminal. Voce roda por ele.
- Um passo de cada vez. Confirme antes de avancar.
- Sempre explique o resultado em linguagem simples e diga o proximo passo.
- Se algo falhar, avise de forma clara, diga a causa provavel e o que fazer.
- Comece SEMPRE em `environment: "sandbox"` (empresa de teste). So use producao
  quando o usuario pedir e confirmar que quer mexer na empresa real.
- SEGURANCA: credenciais ficam SO na maquina do usuario, em
  `scripts/credentials.local.json` (bloqueado por `.gitignore`). Nunca imprima
  token/segredo em texto pleno; nunca cole credencial em resumo/chat.

## Fluxo que o Claude deve seguir

### Passo (a) — Verificar as 4 credenciais da Intuit
Pergunte se o usuario ja tem as 4 credenciais: **Client ID, Client Secret,
Realm/Company ID, Refresh Token**.
- Se JA tem: siga pro passo (b).
- Se NAO tem: conduza pela obtencao usando **`credenciais-intuit.md`** como
  roteiro. Traduza cada passo pra linguagem simples, um de cada vez ("agora abra
  este site", "clique aqui", "me diga o que apareceu"). Nao mande ele fazer tudo
  sozinho de uma vez.

### Passo (b) — Salvar as credenciais e testar a conexao (VOCE faz)
1. Copie o template criando o arquivo local (voce roda):
   `cp scripts/credentials.example.json scripts/credentials.local.json`
2. Escreva as 4 credenciais que o usuario passou dentro de
   `scripts/credentials.local.json` (voce edita o arquivo; deixe
   `environment` como `"sandbox"`). Nunca repita os valores no chat.
3. Teste a conexao rodando por ele:
   `node scripts/test-connection.js`
4. Leia a saida. Se terminar com "CONEXAO OK", diga em linguagem simples:
   "Conectou! Achei sua empresa X e seus dados." Se falhar, veja "Erros comuns".

### Passo (c) — Lancar despesa vinculada ao projeto (VOCE faz)
Quando o usuario passar os dados de uma nota/despesa (valor, e de qual obra/
projeto), rode por ele:
- `node scripts/create-project-expense.js --project="NOME-DO-PROJETO" --amount=VALOR`
- ou `node scripts/create-project-expense.js --project-id=ID --amount=VALOR`
- sem argumentos, ele usa o primeiro projeto que encontrar.

O script descobre os projetos, lanca a despesa vinculada e LE de volta pra provar
que vinculou (read-back). Explique o VEREDITO em linguagem simples:
- "SIM" = despesa lancada e ligada ao projeto. Peca pro usuario conferir na tela
  do QuickBooks (abrir o projeto > aba de custos) — dupla prova.
- Se o alvo saiu como "SubCustomer(Job) PROXY", explique: "voce ainda nao tem um
  projeto de verdade criado na tela do QuickBooks; crie um em Projects e eu lanço
  de novo." (limite real, ver `limites-reais.md`).

### Passo (d) — Puxar relatorios sob pedido (VOCE faz)
Quando o usuario pedir um relatorio, rode por ele:
- Lucro/prejuizo (P&L / DRE): `node scripts/pull-reports.js`
- Balanco: `node scripts/pull-reports.js --report=BalanceSheet`
- Outros: `--report=CashFlow|CustomerBalance|AgedReceivables|AgedPayables|GeneralLedger|TrialBalance`
- Periodo: `--start=2026-01-01 --end=2026-12-31`

Resuma os numeros principais em linguagem simples (ex.: "sua receita foi X, suas
despesas Y, lucro Z"). O JSON completo fica salvo em `scripts/out/`.

## Pre-requisitos honestos (diga isso ao usuario)
- Voce precisa do **Claude Desktop ou Claude Code com a pasta desta skill
  acessivel**, pra que o Claude possa RODAR os scripts por voce. Sem esse acesso,
  o Claude nao consegue executar — nao existe versao "so no navegador".
- Precisa de **Node 18+** instalado na maquina (o Claude checa com `node --version`).
- A **autorizacao unica do QuickBooks (as 4 credenciais) e inevitavel** — e a
  Intuit exigindo que voce prove que a conta e sua. E uma vez so; depois o Claude
  renova o acesso sozinho.
- Despesa por projeto exige plano **QBO Plus ou Advanced** (o sandbox ja e Plus).

## Prompt pronto pro usuario
O usuario pode colar o prompt de **`prompt.md`** no Claude pra disparar tudo isso.

## Limites reais (comprovados — nunca prometa o que nao da)
Detalhe em **`limites-reais.md`**. Resumo honesto:
- A API **NAO cria Project**: o projeto tem que existir na TELA do QBO (exige
  Plus/Advanced). Via API so da pra criar sub-customer comum como proxy.
- A API **NAO le extrato bancario** (feed bruto do banco); trabalha com lancamentos
  contabeis (despesas, contas, faturas) e relatorios.
- O vinculo despesa->projeto FUNCIONA (provado: CustomerRef persistiu,
  BillableStatus=Billable, ReimburseCharge criado).

## Erros comuns (como explicar e resolver)
| Saida do script | O que significa | O que voce (Claude) faz |
|---|---|---|
| "Faltam credenciais" | `credentials.local.json` vazio ou com "COLE_AQUI" | volte ao passo (a)/(b) e preencha as 4 |
| Falha no refresh (HTTP 400) | refresh token expirou (~100 dias) | conduza o usuario a gerar um novo no OAuth Playground (ver credenciais-intuit.md) |
| "refresh_token rotacionado e salvo" | normal — a Intuit troca o token a cada uso | so avise: "atualizei seu acesso automaticamente" |
| "Nenhuma conta Expense/Bank" | empresa sem plano de contas | no sandbox ja vem pronto; na real, peca pra criar contas |
| Alvo = "SubCustomer(Job) PROXY" | nao existe projeto real | peca pra criar um Project na tela do QBO e rode de novo |
| Report 400 | nome de relatorio invalido | use um da lista do passo (d) |

## Arquivos
- `SKILL.md` — este guia (instrucoes pro Claude conduzir e executar).
- `prompt.md` — prompt pronto pro usuario colar.
- `credenciais-intuit.md` — como gerar as 4 credenciais na Intuit.
- `limites-reais.md` — o que funciona / o que nao funciona (comprovado).
- `checklist.md` — como concluir "deu certo / nao deu certo".
- `scripts/qbo-lib.js` — biblioteca (OAuth + helpers + mascaramento de segredo).
- `scripts/test-connection.js` — testa a conexao.
- `scripts/create-project-expense.js` — despesa vinculada a projeto + read-back.
- `scripts/pull-reports.js` — relatorios (P&L, balanco, etc.).
- `scripts/credentials.example.json` — template (copie p/ `credentials.local.json`).
- `scripts/.gitignore` e `.gitignore` (raiz) — bloqueiam credenciais e saidas.
