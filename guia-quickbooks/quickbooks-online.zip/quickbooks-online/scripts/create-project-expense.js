#!/usr/bin/env node
'use strict';
/**
 * create-project-expense.js
 *
 * Lanca uma despesa (Purchase) vinculada a um Project do QuickBooks Online.
 * No QBO, um "Project" e tecnicamente um sub-customer com IsProject=true. O
 * vinculo da despesa ao project e feito pelo campo
 * AccountBasedExpenseLineDetail.CustomerRef.
 *
 * Fluxo (PROVADO contra o sandbox real da Intuit):
 *   1. Renova o access token via OAuth2.
 *   2. Descobre Projects (Customer com IsProject=true) e sub-customers.
 *   3. Escolhe um alvo:
 *        - Se voce passar --project="Nome" ou --project-id=123, usa esse.
 *        - Senao usa o primeiro Project real encontrado.
 *        - Se NAO houver nenhum Project real, cria um parent + sub-customer
 *          (Job=true) como PROXY e AVISA a limitacao (a API nao cria Project
 *          real; Project precisa existir na tela do QBO — ver limites-reais.md).
 *   4. Localiza uma conta Expense e uma conta Bank.
 *   5. Posta a Purchase com CustomerRef apontando pro project.
 *   6. Le a Purchase de volta (GET) e verifica se o CustomerRef persistiu.
 *
 * Uso:
 *   node scripts/create-project-expense.js
 *   node scripts/create-project-expense.js --project="PROJ-001" --amount=42
 *   node scripts/create-project-expense.js --project-id=58 --amount=150.50
 *
 * Requer Node 18+.
 */

const {
  loadConfig,
  apiBase,
  section,
  refreshAccessToken,
  apiQuery,
  apiCreate,
  apiGet,
} = require('./qbo-lib');

// --- argumentos simples (--chave=valor) ------------------------------------
function parseArgs() {
  const out = {};
  for (const a of process.argv.slice(2)) {
    const m = a.match(/^--([^=]+)=(.*)$/);
    if (m) out[m[1]] = m[2];
    else if (a.startsWith('--')) out[a.slice(2)] = true;
  }
  return out;
}
const ARGS = parseArgs();
const AMOUNT = Number(ARGS.amount || 42);
const DESIRED_PROJECT = ARGS.project || null; // nome (DisplayName)
const DESIRED_PROJECT_ID = ARGS['project-id'] || null;

// ---------------------------------------------------------------------------
async function discoverProjects(cfg, token) {
  section('PASSO 2 - Descobrindo Projects (Customer + IsProject)');
  const resp = await apiQuery(cfg, token, 'SELECT * FROM Customer MAXRESULTS 1000');
  const customers = resp.Customer || [];
  const projects = customers.filter((c) => c.IsProject === true);
  const subcustomers = customers.filter((c) => c.Job === true || c.ParentRef);
  console.log(`Total de Customers: ${customers.length}`);
  console.log(`Projects reais (IsProject=true): ${projects.length}`);
  console.log(`Sub-customers (Job=true / ParentRef): ${subcustomers.length}`);
  if (projects.length) {
    console.log('\nProjects encontrados:');
    projects.forEach((p) => console.log(`  - Id=${p.Id} "${p.DisplayName}"`));
  }
  return { customers, projects, subcustomers };
}

async function ensureProjectTarget(cfg, token, discovered) {
  section('PASSO 3 - Escolhendo o Project alvo');

  // 1. usuario pediu um project especifico
  if (DESIRED_PROJECT_ID) {
    const p = discovered.customers.find((c) => String(c.Id) === String(DESIRED_PROJECT_ID));
    if (p) {
      console.log(`Usando alvo por --project-id: Id=${p.Id} "${p.DisplayName}" IsProject=${p.IsProject === true}`);
      return { ref: p, kind: p.IsProject ? 'IsProject' : 'Customer/Sub' };
    }
    console.log(`AVISO: nao achei Customer com Id=${DESIRED_PROJECT_ID}. Caindo pro padrao.`);
  }
  if (DESIRED_PROJECT) {
    const p = discovered.customers.find(
      (c) => (c.DisplayName || '').toLowerCase() === DESIRED_PROJECT.toLowerCase()
    );
    if (p) {
      console.log(`Usando alvo por --project: Id=${p.Id} "${p.DisplayName}" IsProject=${p.IsProject === true}`);
      return { ref: p, kind: p.IsProject ? 'IsProject' : 'Customer/Sub' };
    }
    console.log(`AVISO: nao achei Project com nome "${DESIRED_PROJECT}". Caindo pro padrao.`);
  }

  // 2. primeiro Project real
  if (discovered.projects.length) {
    const p = discovered.projects[0];
    console.log(`Usando primeiro Project real: Id=${p.Id} "${p.DisplayName}"`);
    return { ref: p, kind: 'IsProject' };
  }

  // 3. nenhum project — cria PROXY e avisa a limitacao real
  console.log('Nenhum Project real (IsProject=true) encontrado.');
  console.log('LIMITE REAL: a API NAO cria Project (IsProject=true). Projects exige');
  console.log('QBO Plus/Advanced e o Project precisa ser criado na TELA do QBO.');
  console.log('Criando parent + sub-customer (Job=true) como PROXY so pra demonstrar');
  console.log('o vinculo. Para o vinculo real ao Project, crie o Project na tela e rode de novo.');

  const stamp = Date.now();
  const parent = await apiCreate(cfg, token, 'Customer', {
    DisplayName: `Cliente Exemplo ${stamp}`,
    CompanyName: `Cliente Exemplo ${stamp}`,
  });
  const parentObj = parent.Customer;
  console.log(`Parent criado: Id=${parentObj.Id} "${parentObj.DisplayName}"`);

  const sub = await apiCreate(cfg, token, 'Customer', {
    DisplayName: `PROJ-001 ${stamp}`,
    Job: true,
    ParentRef: { value: parentObj.Id },
  });
  const subObj = sub.Customer;
  console.log(`Sub-customer (proxy) criado: Id=${subObj.Id} "${subObj.DisplayName}" IsProject=${subObj.IsProject === true}`);
  return { ref: subObj, kind: subObj.IsProject ? 'IsProject' : 'SubCustomer(Job) PROXY' };
}

async function findAccounts(cfg, token) {
  section('PASSO 4 - Localizando contas (Expense + Bank)');
  const exp = await apiQuery(cfg, token, "SELECT * FROM Account WHERE AccountType = 'Expense' MAXRESULTS 5");
  const bank = await apiQuery(cfg, token, "SELECT * FROM Account WHERE AccountType = 'Bank' MAXRESULTS 5");
  const expense = (exp.Account || [])[0];
  const bankAcct = (bank.Account || [])[0];
  if (!expense) throw new Error('Nenhuma conta Expense encontrada.');
  if (!bankAcct) throw new Error('Nenhuma conta Bank encontrada.');
  console.log(`Conta de despesa: Id=${expense.Id} "${expense.Name}"`);
  console.log(`Conta de pagamento (Bank): Id=${bankAcct.Id} "${bankAcct.Name}"`);
  return { expense, bankAcct };
}

async function createExpenseForProject(cfg, token, projectRef, expense, bankAcct) {
  section('PASSO 5 - Criando a Purchase (despesa) vinculada ao Project');
  const payload = {
    PaymentType: 'Check',
    AccountRef: { value: bankAcct.Id, name: bankAcct.Name },
    Line: [
      {
        DetailType: 'AccountBasedExpenseLineDetail',
        Amount: AMOUNT,
        Description: `Despesa vinculada ao project ${projectRef.DisplayName} (Id ${projectRef.Id})`,
        AccountBasedExpenseLineDetail: {
          AccountRef: { value: expense.Id, name: expense.Name },
          CustomerRef: { value: projectRef.Id, name: projectRef.DisplayName },
          BillableStatus: 'Billable',
        },
      },
    ],
  };
  console.log('Payload enviado:');
  console.log(JSON.stringify(payload, null, 2));
  const created = await apiCreate(cfg, token, 'Purchase', payload);
  const id = created.Purchase.Id;
  console.log(`\nOK - Purchase criada. Id=${id}`);
  return id;
}

async function verifyReadBack(cfg, token, purchaseId, projectRef) {
  section('PASSO 6 - Lendo a Purchase de volta e verificando o CustomerRef');
  const back = await apiGet(cfg, token, 'Purchase', purchaseId);
  const line = (back.Purchase.Line || []).find(
    (l) => l.DetailType === 'AccountBasedExpenseLineDetail'
  );
  const detail = line && line.AccountBasedExpenseLineDetail;
  const custRef = detail && detail.CustomerRef;

  console.log('Linha lida de volta:');
  console.log(JSON.stringify(line, null, 2));

  section('VEREDITO');
  if (custRef && String(custRef.value) === String(projectRef.Id)) {
    console.log('RESULTADO: SIM - o CustomerRef ficou gravado na linha da despesa.');
    console.log(`  CustomerRef.value = ${custRef.value} (esperado ${projectRef.Id})`);
    console.log(`  BillableStatus    = ${detail.BillableStatus}`);
    console.log('  => A API ACEITOU vincular a despesa ao project/sub-customer.');
    console.log('  => CONFIRME na tela: abra o Project no QBO e veja a transacao na aba de custos.');
  } else if (custRef) {
    console.log('RESULTADO: PARCIAL - existe CustomerRef mas com valor diferente.');
    console.log(`  Esperado ${projectRef.Id}, veio ${custRef.value}.`);
  } else {
    console.log('RESULTADO: NAO - o CustomerRef NAO voltou na linha.');
    console.log('  A API aceitou o POST mas nao gravou/retornou o CustomerRef.');
    console.log('  Anote a minor version usada:', cfg.minorVersion);
  }
  return { purchaseId, projectId: projectRef.Id, custRef: custRef || null };
}

(async () => {
  const cfg = loadConfig();
  console.log('Ambiente:', cfg.environment, '| API base:', apiBase(cfg), '| minorversion:', cfg.minorVersion);
  console.log('Valor da despesa:', AMOUNT);

  section('PASSO 1 - OAuth2: renovando access token');
  const token = await refreshAccessToken(cfg);

  const discovered = await discoverProjects(cfg, token);
  const target = await ensureProjectTarget(cfg, token, discovered);
  const { expense, bankAcct } = await findAccounts(cfg, token);
  const purchaseId = await createExpenseForProject(cfg, token, target.ref, expense, bankAcct);
  const result = await verifyReadBack(cfg, token, purchaseId, target.ref);

  section('RESUMO FINAL');
  console.log('Alvo usado           :', target.kind, '(Id', target.ref.Id + ')');
  console.log('Purchase criada (Id) :', result.purchaseId);
  console.log('CustomerRef gravado  :', result.custRef ? 'SIM (' + result.custRef.value + ')' : 'NAO');
  console.log('\nAbra o QBO e valide na tela (ver checklist.md).');
})().catch((e) => {
  console.error('\n[FALHA]', e.message);
  process.exit(1);
});
