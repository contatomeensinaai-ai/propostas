'use strict';
/**
 * qbo-lib.js — biblioteca compartilhada (zero dependencia, fetch nativo).
 *
 * Requer Node 18+ (usa fetch nativo). Testado em Node 24.
 *
 * NAO ha segredo hardcoded. As credenciais vem SEMPRE da maquina do usuario:
 *   - credentials.local.json (na pasta scripts/, ignorado pelo git), OU
 *   - variaveis de ambiente QBO_CLIENT_ID / QBO_CLIENT_SECRET / QBO_REALM_ID /
 *     QBO_REFRESH_TOKEN.
 * Nunca comite credentials.local.json. O .gitignore ja bloqueia.
 */

const fs = require('fs');
const path = require('path');

const CREDENTIALS_FILE = path.join(__dirname, 'credentials.local.json');

// ---------------------------------------------------------------------------
// Seguranca: mascarar segredos. NUNCA imprima token/secret em texto pleno.
// ---------------------------------------------------------------------------
function maskSecret(value) {
  const s = String(value || '');
  if (s.length <= 4) return '****';
  return '...' + s.slice(-4);
}

// Redige quaisquer segredos conhecidos que apareçam num texto (ex.: corpo de
// erro da Intuit) antes de imprimir no stdout/stderr.
function redactSecrets(text, cfg) {
  let out = String(text == null ? '' : text);
  const secrets = [cfg && cfg.refreshToken, cfg && cfg.clientSecret, cfg && cfg.accessToken].filter(
    (s) => s && String(s).length >= 6
  );
  for (const s of secrets) {
    out = out.split(String(s)).join('[REDACTED]');
  }
  // redige tambem valores de token que venham num JSON de resposta/erro
  out = out.replace(/("(?:access_token|refresh_token)"\s*:\s*")[^"]+(")/g, '$1[REDACTED]$2');
  return out;
}

// Grava o refresh_token rotacionado de volta no credentials.local.json,
// preservando os demais campos. Retorna true se gravou, false se nao deu
// (ex.: credenciais vieram de env e nao ha arquivo local).
function persistRefreshToken(newToken) {
  try {
    if (!fs.existsSync(CREDENTIALS_FILE)) return false;
    const raw = JSON.parse(fs.readFileSync(CREDENTIALS_FILE, 'utf8'));
    raw.refreshToken = newToken;
    fs.writeFileSync(CREDENTIALS_FILE, JSON.stringify(raw, null, 2) + '\n');
    return true;
  } catch (_e) {
    return false;
  }
}

// ---------------------------------------------------------------------------
// Carregar credenciais (arquivo local OU env). Nada hardcoded.
// ---------------------------------------------------------------------------
function loadConfig() {
  const file = CREDENTIALS_FILE;
  let cfg = {};
  if (fs.existsSync(file)) {
    cfg = JSON.parse(fs.readFileSync(file, 'utf8'));
  }
  const merged = {
    clientId: process.env.QBO_CLIENT_ID || cfg.clientId,
    clientSecret: process.env.QBO_CLIENT_SECRET || cfg.clientSecret,
    realmId: process.env.QBO_REALM_ID || cfg.realmId,
    refreshToken: process.env.QBO_REFRESH_TOKEN || cfg.refreshToken,
    // sandbox por padrao. Troque para 'production' so quando for empresa real.
    environment: process.env.QBO_ENV || cfg.environment || 'sandbox',
    minorVersion: cfg.minorVersion || process.env.QBO_MINOR_VERSION || '73',
  };
  const missing = ['clientId', 'clientSecret', 'realmId', 'refreshToken'].filter(
    (k) => !merged[k] || String(merged[k]).includes('COLE_AQUI')
  );
  if (missing.length) {
    console.error('\n[ERRO] Faltam credenciais:', missing.join(', '));
    console.error('Copie credentials.example.json para credentials.local.json e preencha,');
    console.error('ou exporte QBO_CLIENT_ID, QBO_CLIENT_SECRET, QBO_REALM_ID, QBO_REFRESH_TOKEN.\n');
    process.exit(1);
  }
  return merged;
}

function apiBase(cfg) {
  return cfg.environment === 'production'
    ? 'https://quickbooks.api.intuit.com'
    : 'https://sandbox-quickbooks.api.intuit.com';
}

const OAUTH_TOKEN_URL = 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer';

function section(t) {
  console.log('\n' + '='.repeat(70) + '\n' + t + '\n' + '='.repeat(70));
}

// ---------------------------------------------------------------------------
// OAuth2 - renovar access token a partir do refresh token
// ---------------------------------------------------------------------------
async function refreshAccessToken(cfg) {
  const basic = Buffer.from(`${cfg.clientId}:${cfg.clientSecret}`).toString('base64');
  const body = new URLSearchParams({
    grant_type: 'refresh_token',
    refresh_token: cfg.refreshToken,
  });
  const res = await fetch(OAUTH_TOKEN_URL, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${basic}`,
      'Content-Type': 'application/x-www-form-urlencoded',
      Accept: 'application/json',
    },
    body,
  });
  const text = await res.text();
  if (!res.ok) {
    // Redige segredos conhecidos antes de imprimir o corpo bruto do erro.
    console.error('[ERRO] Falha no refresh do token. HTTP', res.status);
    console.error(redactSecrets(text, cfg));
    console.error('\nDica: refresh tokens do sandbox expiram em ~100 dias e sao');
    console.error('rotacionados a cada uso. Gere um novo no OAuth Playground se preciso.');
    process.exit(1);
  }
  const json = JSON.parse(text);
  console.log('OK - access token obtido. Expira em', json.expires_in, 'segundos.');
  if (json.refresh_token && json.refresh_token !== cfg.refreshToken) {
    // A Intuit rotaciona o refresh_token a cada uso. Grava o novo automaticamente
    // no credentials.local.json e confirma MASCARADO. O valor completo NUNCA
    // aparece no stdout.
    const saved = persistRefreshToken(json.refresh_token);
    cfg.refreshToken = json.refresh_token;
    if (saved) {
      console.log(`refresh_token rotacionado e salvo (final ${maskSecret(json.refresh_token)})`);
    } else {
      console.log(
        `refresh_token rotacionado (final ${maskSecret(json.refresh_token)}). ` +
          'Nao foi possivel gravar em credentials.local.json (credenciais via env?). ' +
          'Atualize sua fonte de credenciais antes do proximo run.'
      );
    }
  }
  return json.access_token;
}

// ---------------------------------------------------------------------------
// Helpers de API
// ---------------------------------------------------------------------------
async function apiQuery(cfg, token, query) {
  const url = `${apiBase(cfg)}/v3/company/${cfg.realmId}/query?query=${encodeURIComponent(
    query
  )}&minorversion=${cfg.minorVersion}`;
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' },
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`Query falhou HTTP ${res.status}: ${text}`);
  return JSON.parse(text).QueryResponse || {};
}

async function apiCreate(cfg, token, entity, payload) {
  const url = `${apiBase(cfg)}/v3/company/${cfg.realmId}/${entity.toLowerCase()}?minorversion=${cfg.minorVersion}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`Create ${entity} falhou HTTP ${res.status}: ${text}`);
  return JSON.parse(text);
}

async function apiGet(cfg, token, entity, id) {
  const url = `${apiBase(cfg)}/v3/company/${cfg.realmId}/${entity.toLowerCase()}/${id}?minorversion=${cfg.minorVersion}`;
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' },
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`GET ${entity}/${id} falhou HTTP ${res.status}: ${text}`);
  return JSON.parse(text);
}

// GET /reports/{ReportName} — ex: ProfitAndLoss, BalanceSheet, CustomerBalance
async function apiReport(cfg, token, reportName, params = {}) {
  const qs = new URLSearchParams({ ...params, minorversion: cfg.minorVersion });
  const url = `${apiBase(cfg)}/v3/company/${cfg.realmId}/reports/${reportName}?${qs.toString()}`;
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' },
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`Report ${reportName} falhou HTTP ${res.status}: ${text}`);
  return JSON.parse(text);
}

module.exports = {
  loadConfig,
  apiBase,
  section,
  refreshAccessToken,
  apiQuery,
  apiCreate,
  apiGet,
  apiReport,
};
