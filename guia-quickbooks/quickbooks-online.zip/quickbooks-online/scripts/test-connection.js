#!/usr/bin/env node
'use strict';
/**
 * test-connection.js
 *
 * Prova que suas credenciais funcionam:
 *   1. Renova o access token via OAuth2 (refresh_token grant).
 *   2. Le o CompanyInfo (nome da empresa) para confirmar o realm/company.
 *   3. Lista uma amostra de Customers e Accounts.
 *
 * Uso: node scripts/test-connection.js
 * Requer Node 18+.
 */

const { loadConfig, apiBase, section, refreshAccessToken, apiQuery } = require('./qbo-lib');

(async () => {
  const cfg = loadConfig();
  console.log('Ambiente:', cfg.environment, '| API base:', apiBase(cfg), '| minorversion:', cfg.minorVersion);

  section('PASSO 1 - OAuth2: renovando access token');
  const token = await refreshAccessToken(cfg);

  section('PASSO 2 - Lendo CompanyInfo (confirma o realm/company)');
  const info = await apiQuery(cfg, token, 'SELECT * FROM CompanyInfo');
  const company = (info.CompanyInfo || [])[0];
  if (company) {
    console.log('Empresa :', company.CompanyName);
    console.log('Pais    :', company.Country || '(nao informado)');
    console.log('RealmId :', cfg.realmId);
  } else {
    console.log('AVISO: CompanyInfo veio vazio. Verifique o realmId.');
  }

  section('PASSO 3 - Amostra de Customers e Accounts');
  const custs = await apiQuery(cfg, token, 'SELECT * FROM Customer MAXRESULTS 5');
  const customers = custs.Customer || [];
  console.log(`Customers (amostra de ${customers.length}):`);
  customers.forEach((c) =>
    console.log(`  - Id=${c.Id} "${c.DisplayName}" IsProject=${c.IsProject === true}`)
  );

  const accts = await apiQuery(cfg, token, 'SELECT * FROM Account MAXRESULTS 5');
  const accounts = accts.Account || [];
  console.log(`\nAccounts (amostra de ${accounts.length}):`);
  accounts.forEach((a) => console.log(`  - Id=${a.Id} "${a.Name}" tipo=${a.AccountType}`));

  section('RESULTADO');
  console.log('CONEXAO OK. Token renovado, empresa lida e dados listados.');
  console.log('Se chegou aqui, suas 4 credenciais estao corretas.');
})().catch((e) => {
  console.error('\n[FALHA]', e.message);
  process.exit(1);
});
