#!/usr/bin/env node
'use strict';
/**
 * pull-reports.js
 *
 * Puxa relatorios financeiros basicos que a Accounting API v3 expoe:
 *   - ProfitAndLoss (DRE / P&L)
 *   - BalanceSheet (Balanco)
 * e imprime um resumo legivel + salva o JSON cru em ./out/.
 *
 * Uso:
 *   node scripts/pull-reports.js
 *   node scripts/pull-reports.js --report=ProfitAndLoss --start=2026-01-01 --end=2026-12-31
 *
 * Relatorios comuns suportados pela API (passe em --report):
 *   ProfitAndLoss, BalanceSheet, CashFlow, CustomerBalance, AgedReceivables,
 *   AgedPayables, GeneralLedger, TrialBalance
 *
 * LIMITE REAL: a API expoe RELATORIOS CONTABEIS. Ela NAO le extrato bancario
 * (transacoes cruas do banco). Ver limites-reais.md.
 *
 * Requer Node 18+.
 */

const fs = require('fs');
const path = require('path');
const { loadConfig, apiBase, section, refreshAccessToken, apiReport } = require('./qbo-lib');

function parseArgs() {
  const out = {};
  for (const a of process.argv.slice(2)) {
    const m = a.match(/^--([^=]+)=(.*)$/);
    if (m) out[m[1]] = m[2];
  }
  return out;
}
const ARGS = parseArgs();

// intervalo padrao: ano corrente
const now = new Date();
const DEFAULT_START = `${now.getFullYear()}-01-01`;
const DEFAULT_END = now.toISOString().slice(0, 10);

const REPORT = ARGS.report || 'ProfitAndLoss';
const START = ARGS.start || DEFAULT_START;
const END = ARGS.end || DEFAULT_END;

// Achata as linhas de um relatorio QBO (estrutura Rows aninhada) em texto simples.
function printRows(rows, indent = 0) {
  if (!rows || !rows.Row) return;
  for (const row of rows.Row) {
    const pad = '  '.repeat(indent);
    if (row.Header && row.Header.ColData) {
      console.log(pad + row.Header.ColData.map((c) => c.value).filter(Boolean).join(' | '));
    }
    if (row.ColData) {
      console.log(pad + row.ColData.map((c) => c.value).filter((v) => v !== '').join(' | '));
    }
    if (row.Rows) printRows(row.Rows, indent + 1);
    if (row.Summary && row.Summary.ColData) {
      console.log(pad + '  = ' + row.Summary.ColData.map((c) => c.value).filter(Boolean).join(' | '));
    }
  }
}

(async () => {
  const cfg = loadConfig();
  console.log('Ambiente:', cfg.environment, '| API base:', apiBase(cfg), '| minorversion:', cfg.minorVersion);

  section('PASSO 1 - OAuth2: renovando access token');
  const token = await refreshAccessToken(cfg);

  section(`PASSO 2 - Puxando relatorio ${REPORT} (${START} a ${END})`);
  const report = await apiReport(cfg, token, REPORT, {
    start_date: START,
    end_date: END,
  });

  const header = report.Header || {};
  console.log('Relatorio:', header.ReportName || REPORT);
  console.log('Periodo  :', header.StartPeriod || START, 'a', header.EndPeriod || END);
  console.log('Moeda    :', header.Currency || '(nao informado)');
  console.log('');
  printRows(report.Rows);

  // salva o JSON cru pra inspecao/uso posterior
  const outDir = path.join(__dirname, 'out');
  fs.mkdirSync(outDir, { recursive: true });
  const outFile = path.join(outDir, `${REPORT}-${START}-a-${END}.json`);
  fs.writeFileSync(outFile, JSON.stringify(report, null, 2));

  section('RESULTADO');
  console.log('Relatorio puxado com sucesso.');
  console.log('JSON cru salvo em:', outFile);
})().catch((e) => {
  console.error('\n[FALHA]', e.message);
  process.exit(1);
});
