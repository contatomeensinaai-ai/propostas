# Como obter as 4 credenciais na Intuit (passo a passo)

Objetivo: sair com **Client ID**, **Client Secret**, **Realm/Company ID** e
**Refresh Token**. Leva ~10 minutos. Comece SEMPRE pelo sandbox (empresa de
teste com dados ficticios) — so passe pra producao depois que tudo funcionar.

> As 4 credenciais sao SUAS e ficam so na SUA maquina, em
> `scripts/credentials.local.json` (bloqueado pelo `.gitignore`). Nunca as
> compartilhe nem as suba pro git.

## Parte 1 — Criar conta de desenvolvedor
1. Abra https://developer.intuit.com
2. Clique em "Sign up" (ou "Sign in" se ja tiver login Intuit/QuickBooks).
3. Confirme o e-mail se pedir.

## Parte 2 — Criar o app (gera Client ID e Client Secret)
4. Logado, va em "Dashboard" (https://developer.intuit.com/app/developer/dashboard).
5. Clique em "Create an app".
6. Escolha a plataforma "QuickBooks Online and Payments".
7. De um nome qualquer (ex: "Minha Integracao") e marque o escopo
   `com.intuit.quickbooks.accounting`. Crie.
8. No app, abra a aba "Keys & credentials".
9. Selecione a secao "Development" (nao "Production").
10. Anote:
    - **Client ID**
    - **Client Secret**

## Parte 3 — O sandbox (empresa de teste) ja vem pronto
11. A conta de dev ja cria um sandbox automaticamente. Confira em
    https://developer.intuit.com/app/developer/sandbox
12. Anote o **Company ID** mostrado ali — esse e o **Realm ID**.

### Habilitar Projects no sandbox (necessario pra despesa-por-projeto)
13. Na pagina de sandbox, clique para abrir a empresa de teste (abre o QBO
    normal, com dados ficticios).
14. No menu lateral, procure "Projects". Se nao aparecer: Settings (engrenagem)
    > Account and settings > Advanced > ative "Projects".
    (Projects exige plano **QBO Plus ou Advanced** — o sandbox ja e Plus.)
15. Crie 1 Project de teste: menu Projects > New project > escolha um cliente
    existente > salve. Assim o script acha um Project real (`IsProject=true`).

## Parte 4 — Gerar o Refresh Token (OAuth Playground)
16. Abra o OAuth 2.0 Playground:
    https://developer.intuit.com/app/developer/playground
17. No topo, selecione o SEU app e o ambiente "Sandbox" / escopo "Accounting".
18. Clique "Get authorization code" e autorize com a empresa sandbox.
19. Clique "Get tokens" / "Exchange". A tela mostra:
    - Access Token (dura 1 hora — nao precisa guardar; o script renova sozinho)
    - **Refresh Token** (dura ~100 dias — ESSE a gente usa)
    - Realm ID (confere com a Parte 3)
20. Anote o **Refresh Token**.

## Parte 5 — Preencher o arquivo local
No terminal, dentro da pasta da skill:
```
cp scripts/credentials.example.json scripts/credentials.local.json
```
Abra `scripts/credentials.local.json` e cole os 4 valores. Deixe
`environment` como `"sandbox"`. Salve.

Teste:
```
node scripts/test-connection.js
```
Se imprimir "CONEXAO OK", suas credenciais estao corretas.

## Passar pra producao (so depois de tudo funcionar no sandbox)
- Na aba "Keys & credentials", pegue as chaves da secao **Production** (Client ID
  e Client Secret sao DIFERENTES do development).
- Gere um novo Refresh Token de producao no fluxo OAuth apontando pra sua
  empresa real.
- Troque `environment` para `"production"` no `credentials.local.json`.
- Producao exige que o app passe pela revisao da Intuit para acesso completo.

> Seguranca: o refresh token da acesso de leitura/escrita a contabilidade. Trate
> como senha. Se vazar, revogue o app na Intuit e gere um novo.
