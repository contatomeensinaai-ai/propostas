# Prompt pronto — cole no Claude Desktop / Claude Code

Copie e cole a mensagem abaixo no Claude (Desktop ou Code) com a pasta desta
skill acessível. O Claude assume a condução e roda tudo por você.

---

Ative a skill quickbooks-online. Quero conectar meu QuickBooks Online e organizar
minhas despesas por obra/projeto, sem eu precisar usar o terminal. Me conduza um
passo de cada vez, em linguagem simples: (1) confira se eu já tenho minhas 4
credenciais da Intuit; se não, me guie a conseguir; (2) salve no lugar certo e
teste a conexão pra mim; (3) me mostre como lançar uma despesa vinculada ao
projeto e faça por mim quando eu te passar os dados da nota; (4) puxe um relatório
se eu pedir. Rode os comandos você mesmo, me explique cada resultado e me avise se
algo não funcionar. Nunca me peça pra digitar comando no terminal.

---

## Variações que também disparam a skill
- "Quero conectar meu QuickBooks e lançar despesas por projeto, faz por mim."
- "Me ajuda a organizar minhas despesas de obra no QuickBooks sem terminal."
- "Puxa meu relatório de lucro (P&L) do QuickBooks."
